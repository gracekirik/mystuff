/*
 * Grace Kirik
 * CSCI 312 Artificial Intelligence, Fall 20199
 */
package othello;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author Grace Kirik
 */
public class Othello {

    public int[] gameBoard;
    public char myColor; 
    public int whoseTurn;
    public final Scanner scan = new Scanner(System.in);
    public final int[] directions = new int[]{-11, -10, -9, -1, 1, 9, 10, 11};
    public int piecesOnBoard;
    static double timeAllocation[] = {0.015, 0.015, 0.015, 0.015, 0.025, 0.025, 0.025, 0.025, 0.025, 0.025,
        0.048, 0.048, 0.048, 0.048, 0.048, 0.048, 0.050, 0.051, 0.052, 0.053,
        0.044, 0.045, 0.049, 0.049, 0.049, 0.051, 0.053, 0.055, 0.057, 0.059,
        0.060, 0.060, 0.061, 0.062, 0.063, 0.064, 0.065, 0.065, 0.065, 0.065,
        0.167, 0.168, 0.169, 0.169, 0.171, 0.172, 0.173, 0.175, 0.180, 0.180,
        0.181, 0.187, 0.196, 0.199, 0.220, 0.220, 0.220, 0.220, 0.220, 0.220,
        0.220, 0.250, 0.250, 0.250, 0.250, 0.250, 0.250, 0.250, 0.250, 0.250
    };
    public int timeRemaining; //declare a variable to keep track of remaining time ..... initialize at beginning of game
    public int timeForMove;
    public Timer timer; //use this to start the interupt task
    public static boolean timeUP;  //boolean flag to check frequently for time up....this is set to true in the 
    //interrupt task
    public int moveNumber = 0;

    class InterruptTask extends TimerTask {

        public void run() {
            System.out.println("C ****>timeup");
            timeUP = true;
            timer.cancel();
        }
    }

    public char getColor() {
        myColor = 'x';
        System.out.println("C Please initiate color (I W or I B):");
        while (myColor == 'x') {
            String input = scan.nextLine();
            if (input.equals("I W")) {
                myColor = 'W';
            } else if (input.equals("I B")) {
                myColor = 'B';
            } else {
                System.out.println("C Invalid input");
            }
        }
        return myColor;
    }

    private int[] newBoard() {
        gameBoard = new int[100];
        for (int i = 0; i < 100; i++) {
            gameBoard[i] = 0;
        }
        //set boarder values to -2
        for (int i = 0; i < 10; i++) {
            gameBoard[i] = -2;
            gameBoard[i + 90] = -2;
            gameBoard[i * 10] = -2;
            gameBoard[(i * 10) + 9] = -2;
        }
        //initialize board
        myColor = getColor();
        if (myColor == 'W') {
            gameBoard[44] = 1;
            gameBoard[45] = -1;
            gameBoard[54] = -1;
            gameBoard[55] = 1;
        } else {
            gameBoard[44] = -1;
            gameBoard[45] = 1;
            gameBoard[54] = 1;
            gameBoard[55] = -1;
        }
        piecesOnBoard = 4;
        return (gameBoard);
    }

    public String printBoard() {
        String str = "C     a b c d e f g h \nC  1  ";
        for (int i = 11; i < 89; i++) {
            //skip boarder cells
            if (i % 10 != 0 && i % 10 != 9) {
                //blank spaces represented by dashes
                if (gameBoard[i] == 0) {
                    str += "- ";
                }
                //replace 1 and -1 with B and W
                if (gameBoard[i] == 1 && myColor == 'B') {
                    str += "B ";
                }
                if (gameBoard[i] == -1 && myColor == 'B') {
                    str += "W ";
                }
                if (gameBoard[i] == 1 && myColor == 'W') {
                    str += "W ";
                }
                if (gameBoard[i] == -1 && myColor == 'W') {
                    str += "B ";
                }
            }
            if (i % 10 == 9) {
                str += "\nC  " + (i + 1) / 10 + "  ";
            }
        }
        str += "\nC  ";
        return str;
    }

    public int[] cloneBoard(int[] currentBoard) {
        int[] clone = new int[100];
        for (int i = 0; i < 100; i++) {
            clone[i] = currentBoard[i];
        }
        return clone;
    }

    public int toCellNumber(String[] input) {
        String col = input[1];
        int c = 0;
        if (col.equals("a")) {
            c = 1;
        } else if (col.equals("b")) {
            c = 2;
        } else if (col.equals("c")) {
            c = 3;
        } else if (col.equals("d")) {
            c = 4;
        } else if (col.equals("e")) {
            c = 5;
        } else if (col.equals("f")) {
            c = 6;
        } else if (col.equals("g")) {
            c = 7;
        } else if (col.equals("h")) {
            c = 8;
        } else {
            System.out.println("C Invalid cell/row input");
            endGame();
        }
        String row = input[2];
        int r = Integer.parseInt(row);

        return ((r * 10) + c);

    }

    public String toColRow(int index) {
        String str = "";
        if (myColor == 'W') {
            str += "W ";
        } else {
            str += "B ";
        }

        int col = index % 10;
        if (col == 1) {
            str += "a ";
        } else if (col == 2) {
            str += "b ";
        } else if (col == 3) {
            str += "c ";
        } else if (col == 4) {
            str += "d ";
        } else if (col == 5) {
            str += "e ";
        } else if (col == 6) {
            str += "f ";
        } else if (col == 7) {
            str += "g ";
        } else if (col == 8) {
            str += "h ";
        }

        int row = (index - (index % 10)) / 10;
        str += "" + row;

        return (str);
    }
    
    public String listString(List<Move> moveList){
        String str = "C "+moveList.get(0).getPos();
        if(moveList.size()>1){
            for(int i=1; i<moveList.size(); i++){
                str+=" "+moveList.get(i).getPos();
            }
        }
        return str;
    }

    public boolean gameOver() {
        //if board is full, return true
        if (piecesOnBoard == 64) {
            return true;
        }
        
        //if no moves for either player
        List<Move> myMoves = availableMoves(1, gameBoard);
        System.out.println("C my moves: "+listString(myMoves));
        List<Move> oppMoves = availableMoves(-1, gameBoard);
        System.out.println("C opp moves: "+listString(oppMoves));
        return myMoves.get(0).pos==0 && oppMoves.get(0).pos==0;
    }

    private int endGame() {
        //to count up number of black pieces on board
        int numberBlack = 0;
        for (int i = 1; i < 100; i++) {
            if (myColor == 'B' && gameBoard[i] == 1) {
                numberBlack++;
            }
            if (myColor == 'W' && gameBoard[i] == -1) {
                numberBlack++;
            }
        }
        return numberBlack;
    }

    public List<Move> availableMoves(int player, int[] board) {
        List<Move> moveList = new ArrayList<>();
        for (int i = 11; i < 89; i++) {
            //find empty space
            if (board[i] == 0) {
                //go in each direction
                boolean valid = false;
                List<Integer> flips = new ArrayList<>();
                for (int j = 0; j < 8; j++) {
                    int pos = i + directions[j];
                    List<Integer> maybeFlips = new ArrayList<>();
                    if (board[pos] == -player) {
                        while (board[pos] == -player) {
                            maybeFlips.add(pos);
                            pos += directions[j];
                        }
                        if (board[pos] == player) {
                            valid = true;
                            flips.addAll(maybeFlips);
                        }
                    }
                }
                if (valid) {
                    moveList.add(new Move(i, flips));
                }
            }
        }
        if (moveList.isEmpty()) {
            moveList.add(new Move(0));
        }
        return moveList;

    }

    public int getOpponentMove() {
        System.out.println("C Enter valid move (B c r  or  W c r)");
        String str = scan.nextLine();
        String delims = "[ ]+";
        String[] input = str.split(delims);
        //ignore comments
        while (input[0].equals("C")) {
            str = scan.nextLine();
            input = str.split(delims);
        }
        //ensure opponent is playing their own color
        if ((myColor == 'W' && input[0].equals("W")) || (myColor == 'B' && input[0].equals("B"))) {
            System.out.println("C Invalid input. Game Over.");
            endGame();
        }

        //if input is a number, game over! Count & return number of black pieces.
        if (!input[0].equals("W") && !input[0].equals("B")) {
            endGame();
        }

        //if a skip, return 0
        if (input.length == 1) {
            return 0;
        }

        return toCellNumber(input);
    }

    public Move validateOppMove(int cell) {
        List<Move> oppMoves = availableMoves(-1, gameBoard);
        Move validMove = new Move(0);
        for (int i = 0; i < oppMoves.size(); i++) {
            if (oppMoves.get(i).getPos() == cell) {
                validMove = oppMoves.get(i);
            }
        }
        return validMove;
    }

    // to be used to apply final move
    public void applyMove(Move move) {
        gameBoard[move.getPos()] = whoseTurn;
        //flip tiles accordingly
        for (int i = 0; i < move.getFlips().size(); i++) {
            gameBoard[move.getFlips().get(i)] = whoseTurn;
        }
        if (whoseTurn == 1) {
            System.out.println(toColRow(move.getPos()));
        }
        piecesOnBoard++;
    }

    // to be used in evaluation and alphaBeta functions
    public void testApplyMove(Move move, int player, int[] board) {
        if(move.getPos()!=0){
            board[move.getPos()] = player;
            for (int i = 0; i < move.getFlips().size(); i++) {
                board[move.getFlips().get(i)] = player;
            }
        }
    }

    public Move getMyMove() {
        timeUP = false;  //time up is false at the beginning of move
        timer = new Timer();  //initialize the new timer
        moveNumber++;
        timeForMove = (int) (timeAllocation[moveNumber] * (double) timeRemaining);
        System.out.println("C Move Time:  " + timeForMove + "");
        System.out.println("C Time remaining: "+timeRemaining);
        timer.schedule(new InterruptTask(), timeForMove );  //schedule the  interrupt task
 
        List<Move> moves = availableMoves(1, gameBoard);

        double alpha = Double.MIN_VALUE;
        double beta = Double.MAX_VALUE;
        while (!timeUP) {
            
            return alphaBeta(cloneBoard(gameBoard), 0, 1, alpha, beta, 8);
            
        }
        
        
        System.out.println("C I don't know what's happening");
        return (moves.get(0));
        


        // original:
        // int bestMove = evaluateMoves(moves);
        // return(moves.get(bestMove));

    }

    public Move alphaBeta(int[] board, int ply, int player, double alpha, double beta, int maxDepth) {
        if (ply >= maxDepth) {
            Move returnMove = new Move(0);
            returnMove.Value = evaluateBoard(board, player);
            return returnMove;
        } else {
            List<Move> moves = availableMoves(player, board);
            Move bestMove = moves.get(0);
            for (Move move : moves) {
                int[] newBoard = cloneBoard(board);
                testApplyMove(move, player, newBoard);
                Move tempMove = alphaBeta(newBoard, ply + 1, -player, -beta, -alpha, maxDepth);
                move.Value = -tempMove.Value;
                if (move.Value > alpha) {
                    bestMove = move;
                    alpha = move.Value;
                    if (alpha > beta) {
                        return bestMove;
                    }
                }
            }
            //System.out.println("C ply: "+ply+", player: "+player+", move: "+bestMove.printMove());
            return bestMove;
        }

    }
    
  
    

    public int evaluateMoves(List<Move> list) {
        //max disk strategy
        int max = 0;
        if (list.get(0).getPos() != 0) {
            for (int i = 0; i < list.size(); i++) {
                list.get(i).setValue(list.get(i).flips.size());
                if (list.get(i).getValue() > list.get(max).getValue()) {
                    max = i;
                }
            }
        }
        return max;
    }

    public int evaluateBoard(int[] currentBoard, int player) {
        List<Move> playerMoves = availableMoves(player, currentBoard);
        List<Move> oppMoves = availableMoves(-player, currentBoard);
        int[] weightedBoard = weightedBoard(currentBoard);
        //first see if it's end of game
        boolean fullboard = true;
        int netpieces = 0;
        int totalpieces = 0;
        for (int i = 0; i < 100; i++) {
            netpieces += currentBoard[i];
            if (currentBoard[i] == 0) {
                fullboard = false;
            } else totalpieces++;
        }
        netpieces = netpieces * player;
        if (fullboard) {
            if (netpieces != 0) {
                return (netpieces * 100000);
            } else return (999999);
        }
        netpieces = netpieces / totalpieces;
        
        int currentMobility = (playerMoves.size() - oppMoves.size()) / (playerMoves.size() + oppMoves.size());
        
        int playerStable = 0;
        int oppStable = 0;
        for(int i=11; i<89; i++){
            if(currentBoard[i]==player){
                boolean stable = true;
                for(Move move : oppMoves){
                    if(move.pos !=0 && move.flips.contains(i)){
                        stable=false;
                    }
                }
                if(stable) playerStable++;
            }
            if(currentBoard[i]==-player){
                boolean stable = true;
                for(Move move : playerMoves){
                    if(move.pos !=0 && move.flips.contains(i)){
                        stable=false;
                    }
                }
                if(stable) oppStable++;
            }   
        }
        int stability;
        if(playerStable != 0 && oppStable != 0){
            stability = (playerStable - oppStable) / (playerStable + oppStable);
        }
        else stability = 0;

        int boardWeight = 0;
        for (int i = 0; i < 100; i++) {
            boardWeight += player * currentBoard[i] * weightedBoard[i];
        }

        int val = netpieces + currentMobility + boardWeight + 2 * stability;
        return val;
    }

    public int[] weightedBoard(int[] currentBoard) {
        int[] weights = new int[100];
        //default value is 5
        for (int i = 0; i < 100; i++) {
            weights[i] = 5;
        }

        //set boarder(-2) values to 0
        for (int i = 0; i < 10; i++) {
            weights[i] = 0;
            weights[i + 90] = 0;
            weights[i * 10] = 0;
            weights[(i * 10) + 9] = 0;
        }

        //set corners
        weights[11] = weights[18] = weights[81] = weights[88] = 60;

        //if corner is open, avoid spaces surrounding it
        //corner 1
        if (currentBoard[11] == 0) {
            weights[22] = -60;
            weights[12] = weights[21] = -10;
        } else {
            weights[12] = weights[21] = weights[22] = 45;
        }
        //corner 2
        if (currentBoard[18] == 0) {
            weights[27] = -60;
            weights[17] = weights[28] = -10;
        } else {
            weights[17] = weights[27] = weights[28] = 45;
        }
        //corner 3
        if (currentBoard[81] == 0) {
            weights[72] = -60;
            weights[71] = weights[82] = -10;
        } else {
            weights[71] = weights[72] = weights[82] = 45;
        }
        //corner 4
        if (currentBoard[88] == 0) {
            weights[77] = -60;
            weights[78] = weights[87] = -10;
        } else {
            weights[77] = weights[78] = weights[87] = 45;
        }

        //set remaining edges to 40
        int[] edges = new int[]{13, 14, 15, 16, 32, 42, 52, 62, 37, 47, 57, 67, 73, 74, 75, 76};
        for (int i = 0; i < edges.length; i++) {
            weights[edges[i]] = 40;
        }

        return weights;
    }

    public void playGame() {
        gameBoard = newBoard();
        timeRemaining = 540000; // 10 minutes = 600000 miliseconds
        if (myColor == 'B') {
            whoseTurn = 1;
            System.out.println("R B");
        } else {
            whoseTurn = -1;
            System.out.println("R W");
        }

        System.out.println(printBoard());

        while (gameOver() == false) {
            Move move;
            if (whoseTurn == 1) {
                move = getMyMove();
                timer.cancel();
                timeRemaining -= timeForMove;
            } else {
                move = validateOppMove(getOpponentMove());
            }
            if (move.getPos() != 0) {
                applyMove(move);
            } else {
                if (whoseTurn == 1) {
                    System.out.println(myColor);
                }
            }
            System.out.println(printBoard());

            whoseTurn = whoseTurn * -1;
        }

        //to print out number of black pieces
        System.out.println(endGame());
        System.exit(0);
    }

    public static void main(String[] args) {
        Othello testgame = new Othello();
        testgame.playGame();

    }

}

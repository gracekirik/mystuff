
package othello;

import java.util.List;

/**
 *
 * @author Grace Kirik
 */
public class Move {
    public double Value;
    public int pos;
    public List<Integer> flips; // integer values for the board cell of tiles needing flipped

    public Move(int pos, List<Integer> flips) {
        this.pos = pos;
        this.flips = flips;
    }
    
    public Move(int pos) {
        this.pos = pos;
    }
    
    
    public double getValue() {
        return Value;
    }

    public void setValue(double Value) {
        this.Value = Value;
    }

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public List<Integer> getFlips() {
        return flips;
    }

    public void setFlips(List<Integer> flips) {
        this.flips = flips;
    }
    
    public String printMove(){
        return "C Pos: "+pos+", value: "+Value;
    }
    
}
